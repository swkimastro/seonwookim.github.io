---
title: English
key: lang-en
permalink: /languages/english.html
cover: /docs/assets/images/languages/lang-en.jpg
lang: en
---

English.

<!--more-->

*_config.yml* or front matter:

```yml
lang: en
lang: en-GB
lang: en-US
lang: en-CA
lang: en-AU
```

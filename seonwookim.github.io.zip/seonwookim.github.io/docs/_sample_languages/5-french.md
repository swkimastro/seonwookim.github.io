---
title: Français (French)
key: lang-fr
permalink: /languages/french.html
cover: /docs/assets/images/languages/lang-fr.jpg
lang: fr
---

Français.

<!--more-->

*_config.yml* or front matter:

```yml
lang: fr
lang: fr-BE
lang: fr-CA
lang: fr-CH
lang: fr-FR
lang: fr-LU
```
